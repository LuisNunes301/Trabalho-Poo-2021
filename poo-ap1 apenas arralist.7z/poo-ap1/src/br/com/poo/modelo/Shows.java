package br.com.poo.modelo;

import java.util.ArrayList;

public class Shows {
	private ArrayList<Evento> evento;
	private VenderIngresso valorIngresso;

	public Shows() {
		this.evento = new ArrayList<Evento>();
		this.valorIngresso = new VenderIngresso();
	}

	public void adicionarEvento(Evento evento) {
		this.evento.add(evento);
	}

	public void listarEventostotais() {
		System.out.println("Esse � s� para testar o arraylist\n");
		for (Evento evento2 : evento) {
			System.out.println(evento2);
		}
	}

	public void listarEventos() {
		System.out.println("Eventos disponiveis: ");
		for (Evento evento2 : evento) {
			if (evento2.getLocalinfos().getCapacidade() == 0) {
				System.out.println("\nEvento esgotado:" + evento2.getNome() + "\n");
			} else if (evento2.getLocalinfos().getCapacidade() > 0) {
				System.out.println(evento2.getNome() + "\nCapacidade: " + evento2.getLocalinfos().getCapacidade()
						+ "\nLocal: " + evento2.getLocalinfos().getEndere�o()+"\n--------------------------");
			}
		}
	}

	public void vendaIngresso(Evento evento, int quantidade) {
		if (evento.getLocalinfos().getCapacidade() > 0) {
			double valorTotal = this.valorIngresso.venderIngresso(evento, quantidade);
			System.out.println("Evento: "+evento.getNome()+"\nvalor total da ingresso(s): " + valorTotal);
		}
	}

	public void definirValorIngresso(double valorIngresso) {
		this.valorIngresso.setValorIngresso(valorIngresso);
	}

}
